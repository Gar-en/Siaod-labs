public class Main {
    public static void main(String[] args) {
        int arr[] = new int[] {1,2,3,4,5,6,7,8,9,10};
        int size = 10;
        Search_algs ans = new Search_algs();
        Fibbonachi fib = new Fibbonachi();
        System.out.println(ans.binarySearch(arr, 7, size));
        System.out.println(ans.interpolation(arr, 5, size));
        System.out.println(fib.fibSearch(arr, 3));
    }
}
