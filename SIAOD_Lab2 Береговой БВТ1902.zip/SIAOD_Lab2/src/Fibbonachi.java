public class Fibbonachi {
    private int i;
    private int p;
    private int q;
    private boolean stop = false;

    private void initalization(int[] arr) {
        stop = false;
        int k = 0;
        int n = arr.length;
        for (; getFibonachiNumber(k + 1) < (n + 1) ;) {
            k++;
        }
        int m = (int) (getFibonachiNumber(k + 1) - (n + 1));
        i = (int) (getFibonachiNumber(k) - m);
        p = (int) (getFibonachiNumber(k - 1));
        q = (int) (getFibonachiNumber(k - 2));
    }



    private void upIndex() {
        if (p == 1)
            stop = true;
        i = i + q;
        p = p - q;
        q = q - p;
    }

    private void downIndex() {
        if (q == 0)
            stop = true;
        i = i - q;
        int temp = q;
        q = p - q;
        p = temp;
    }

    public long getFibonachiNumber(int k) {
        long number1 = 0;
        long number2 = 1;
        for (int i = 0; i < k; i++) {
            long temp = number2;
            number2 += number1;
            number1 = temp;
        }
        return number1;
    }

    public int fibSearch(int[] arr, int goal) {
        initalization(arr);
        int n = arr.length;
        int resIndex = -1;
        for (; !stop;) {
            if (i < 0) {
                upIndex();
            } else if (arr[i] == goal) {
                resIndex = i;
                break;
            } else if (goal < arr[i]) {
                downIndex();
            } else if (goal > arr[i]) {
                upIndex();
            }
        }
        return resIndex;
    }
}
