public class Search_algs {
    public int binarySearch(int arr[], int goal, int size) {
        int first = 0;
        int last = size - 1;
        int mid;
        while (first <= last) {
            mid = (first + last) / 2;
            if (arr[mid] == goal)
                return mid;
            else if (arr[mid] < goal)
                first = mid + 1;
            else if (arr[mid] > goal)
                last = mid - 1;
        }
        return -1;
    }

    public int interpolation(int arr[], int goal, int size) {
        int first = 0;
        int last = size - 1;
        int pos;
        while (first <= last && goal > arr[first] && goal < arr[last]) {
            pos = first + ((arr[last] - arr[first]) * (goal - arr[first]) / (last - first));
            if (arr[pos] == goal)
                return pos;
            if (arr[pos] < goal)
                first = pos + 1;
            else last = pos - 1;
        }
        return -1;
    }

    /* public int fibonachi(int arr[], int goal, int size){
        int fib0 = 0;
        int fib1 = 1;
        int fib2 = fib0 + fib1;
        int k = 0;

        while (fib2 < size){
            fib0 = fib1;
            fib1 = fib2;
            fib2 = fib0 + fib1;
            k++;
        }

        while (fib2 > 1) {

        }
    } */

}
