#include "tasks.cpp"

using namespace std;




int main()
{
    task1();

    task2();

    task3();

    return 0;
}
