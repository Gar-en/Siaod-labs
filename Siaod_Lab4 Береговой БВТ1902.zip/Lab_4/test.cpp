#include <iostream>
#include <sstream>
#include "dataStructures.cpp"
using namespace std;

int maisn()
{
    stack<char> test;

    int a=23;
    while(!test.isEmpty())
    {
        cout<<test.end();
        test.pop_back();
    }
}
