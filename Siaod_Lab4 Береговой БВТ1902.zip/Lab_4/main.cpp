#include "dataStructures.cpp"
#include "tasks.cpp"

using namespace std;

int main()
{

    task1();

    task2();

    task3();

    task4();

    task5();

    task6();

    task7();

    task8();

    task9();

    task10();

    return 0;
}
